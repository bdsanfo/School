import java.util.*;
/**
*@author Bobby Sanford
*/
public interface Boundaries{
	/**
	*sets the boundary length of every part of heirarchy
	*/
	public void setBoundaryLength(int length);
}