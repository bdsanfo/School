import java.io.*;

public class Puff{
	
}