public class Robot{
	public static void main(String[] args){
		new RobotFrame();
	}
}