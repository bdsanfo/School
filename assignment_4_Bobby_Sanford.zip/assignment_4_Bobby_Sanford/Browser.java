public class Browser{
	public static void main(String[] args){
		new BrowserFrame();
	}
}