public class PercentDifference{
	
}