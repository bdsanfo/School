public class Greeting {
	public static void main(String[] args){
		System.out.println("Hey! What's up? You from outta town?");
	}
}