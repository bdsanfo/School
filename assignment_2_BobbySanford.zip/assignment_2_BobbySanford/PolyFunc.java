/**
	PolyFunc.java turns an array into a polynomial function that can then be
	used to get the highest degree, print as a string, add polynomials, and 
	evaluate polynomials
	@author Bobby Sanford
*/

public class PolyFunc extends Function{
	
	private int[] coefficients;

	/**
		Turns array into a PolyFunc object
		@param coefficients The array that gets made into the polynomial function
	*/
	PolyFunc(int[] coefficients){
		this.coefficients = new int[coefficients.length];
		for (int i=0; i < coefficients.length; i++){
			this.coefficients [i] = coefficients[i];
		}
	}

	/**
		Gets the highest degree of the PolyFunc
		@return highest degree
	*/
	public int degree(){	
		int highestPower = (coefficients.length-1);
		return highestPower;
	}

	/**
		Turns a PolyFunc into a string
		@return String form of passed in polynomial
	*/
	@Override
	public String toString(){
		PolyBuilder coeff = new PolyBuilder();

		String polynomial = "";
		
		for (int i=(coefficients.length-1); i>=0; i--){

			if(coefficients[i] == 0){
				polynomial = polynomial;
			}
			else if (i == 0) { //last part of polynomial
				polynomial += (coefficients[i]);
			}
			else if (i != coefficients.length-1) { //1st part of polynomial
				polynomial += (coeff.signChoice(coefficients[i])+ coeff.coefficientChoice(coefficients[i]) + coeff.exponentChoice(i));  
			}
			else {
				polynomial += (coeff.coefficientChoice(coefficients[i]) + coeff.exponentChoice(i)); 
			}
		}
		return polynomial;
	}

	/**
		Adds two Poly functions
		@param a the PolyFunc to add to the other PolyFunc
		@return new PolyFunc object of the two summed PolyFuncs
	*/
	PolyFunc add(PolyFunc a){
		int[] addArray = new int[(this.degree()+1)];
		int[] tempArray;
		
		if (this.degree() < a.degree() ){
			tempArray = new int[this.degree()+1];
			tempArray = this.coefficients;
			PolyFunc rePass = new PolyFunc(tempArray);
			return a.add(rePass);

		}
		else {
			for (int i=0; i <= a.degree(); i++){
				addArray[i] += (coefficients[i] + a.coefficients[i]);
			}
			for (int i=(a.degree())+1; i <= degree(); i++){
				addArray[i] += coefficients[i];
			}
		PolyFunc newArrayReturnValue = new PolyFunc(addArray);
		return newArrayReturnValue;
		}
		
	}
	/**
		Evaluates the PolyFunc function with the passed in parameter
		@param x the number that replaces the x values of a polynomial function
		@return a double with the value of the function
	*/
	public double evaluate(double x){
		double[] tempCoeffVal = new double[coefficients.length];
		double evaluatedValue = 0;

		for (int i=0; i<= coefficients.length-1; i++){
			tempCoeffVal[i] = Math.pow(x,i);
			evaluatedValue += (tempCoeffVal[i] * coefficients[i]);
		}
		return evaluatedValue;
	}
}