import java.util.*;

public class Poly{
	
	private int[] coefficients;

	Poly(int[] coefficients){
		this.coefficients = new int[coefficients.length];
		for (int i=0; i < coefficients.length; i++){
			this.coefficients [i] = coefficients[i];
		}
	}

	public int degree(){	
		int highestPower = (coefficients.length-1);
		return highestPower;
	}

	@Override
	public String toString(){
		PolyBuilder coeff = new PolyBuilder();

		String polynomial = "";
		
		for (int i=(coefficients.length-1); i>=0; i--){

			if(coefficients[i] == 0){
				polynomial = polynomial;
			}
			else if (i == 0) { //last part of polynomial
				polynomial += (coeff.signChoice(coefficients[i])+ coefficients[i]);
			}
			else if (i != coefficients.length-1) { //1st part of polynomial
				polynomial += (coeff.signChoice(coefficients[i])+ coeff.coefficientChoice(coefficients[i]) + coeff.exponentChoice(i));  
			}
			else {
				polynomial += (coeff.coefficientChoice(coefficients[i]) + coeff.exponentChoice(i)); 
			}
		}
		return polynomial;
	}

	Poly add(Poly a){
		int[] addArray = new int[(this.degree()+1)];
		int[] tempArray;
		
		if (this.degree() < a.degree() ){
			tempArray = new int[this.degree()+1];
			tempArray = this.coefficients;
			Poly rePass = new Poly(tempArray);
			return a.add(rePass);

		}
		else {
			for (int i=0; i <= a.degree(); i++){
				addArray[i] += (coefficients[i] + a.coefficients[i]);
			}
			for (int i=(a.degree())+1; i <= degree(); i++){
				addArray[i] += coefficients[i];
			}
		Poly newArrayReturnValue = new Poly(addArray);
		return newArrayReturnValue;
		}
		
	}

	public double evaluate(double x){
		double[] tempCoeffVal = new double[coefficients.length];
		double evaluatedValue = 0;

		for (int i=0; i<= coefficients.length-1; i++){
			tempCoeffVal[i] = Math.pow(x,i);
			evaluatedValue += (tempCoeffVal[i] * coefficients[i]);
		}
		return evaluatedValue;
	}

	public static void main(String[] args){
		
		int[] coefficients1 = new int[] {4,0,-8,0,3,2};
		int[] coefficients2 = new int[] {0,-2,4,1};
		int[] coefficients3 = new int[] {4,-2,-4,1,3,2};
		
		Poly test1 = new Poly(coefficients1);
		Poly test2 = new Poly(coefficients2);
		Poly addTestObj = new Poly(coefficients3);
		
		String test1String = "2x^5+3x^4-8x^2+4";
		String test2String = "x^3+4x^2-2x";
		String test3String= "2x^5+3x^4+x^3-4x^2-2x+4";
		
		Boolean toStringTest = test1.toString().equals(test1String);
		Boolean addTest1 = test1.add(test2).toString().equals(test2.add(test1).toString());

		if(test1.degree() != 5 && test2.degree() != 3){
			System.out.println("degree test failed");
		} else {System.out.println("degree test passed");}

		if(toStringTest == false){
			System.out.println("toString test failed");
		} else {System.out.println("toString test passed");}
		
		if(addTest1 == false){
			System.out.println("add test failed");
		} else {System.out.println("add test passed");}

		if(test1.evaluate(2) != 84){
			System.out.println("evaluate test failed");
		} else {System.out.println("evaluate test passed");}
	}
}