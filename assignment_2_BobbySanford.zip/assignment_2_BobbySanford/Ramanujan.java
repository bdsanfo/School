import java.util.*;

public class Ramanujan{

	public static void main(String[] args){
		
		try{

		int n = Integer.parseInt(args[0]);
		Factorial factorial = new Factorial();
		double ramanujanPiValue =0;
		
			for (int k=0; k<=n; k++) {
				double kFactorial = factorial.calculate(k);
				double fourKFactorial = factorial.calculate(k*4);
				ramanujanPiValue = ramanujanPiValue + (fourKFactorial*(1103+(26390*k))/((Math.pow(kFactorial,4))*(Math.pow(396,(4*k)))));		
			}
			ramanujanPiValue = 1/(ramanujanPiValue * ((2*Math.sqrt(2))/9801));
			double javaPiVal = Math.PI;
			
			System.out.println("Pi according to the Ramanujan series: "+ramanujanPiValue);
		
			double percentError = Math.abs(((ramanujanPiValue-javaPiVal)/javaPiVal)*100) ;
		
			System.out.println("The percent error between Java's value and the Ramanujan series is: "+ percentError + " percent.");	
		}
		
		catch(IndexOutOfBoundsException e){
			System.out.println("Enter a number in the args[0]. java Ramanujan 'number'");
		}	
	}
}

/*	BigInteger explaination: A BigInteger is stored as a byte array with two's compliment binary representation of the number which is stored
	similarily to an int but and int is not stored as an array. A BigInt requires different methods to do any sort of calculation with it 
	which differs from an array.

	BigDecimal explaination: A BigDecimal has an unscaled limit on the values that is multiplied by the power ten to get the actual value. 
	This differes from a double because a double is a primitive type and is stored as a value multiplied by power two.
*/
