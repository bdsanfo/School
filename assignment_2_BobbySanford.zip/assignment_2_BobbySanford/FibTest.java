public class FibTest{
	private static long startTimeIter;
	private static long endTimeIter;
	private static long startTimeRecur;
	private static long endTimeRecur;

	public static int fibIter(int n){
		int returnFib = 0;
		int[] fib = new int[n];
		fib[0] = 1;
		fib[1] = 1;

		for (int i=2; i<=fib.length-1; i++){	
			fib[i] = fib[i-1] + fib[i-2];
			returnFib = fib[i];   
		}

		return returnFib;
	}

	public static int fibRecur(int n){
		
		if (n==1||n==2){
			return 1;
		}

		return fibRecur(n-1)+fibRecur(n-2);	
	}

	public static void main(String args[]){ 
		
		if(FibTest.fibIter(17)!=1597){
			System.out.println("fibIter failed");
		}

		if(FibTest.fibRecur(17)!=1597){
			System.out.println(" fibRecur failed");
		}

		//Calculate Time fibIter
		long tInitial = System.currentTimeMillis();
		FibTest.fibIter(40);
		long tFinal = System.currentTimeMillis();		
		System.out.println("Time for fibIter to evaluate the 40th Fibonacci number is "+(tFinal-tInitial) + " ms");

		//Calculate time fibRecur
		long tI = System.currentTimeMillis();
		FibTest.fibRecur(40);
		long tF = System.currentTimeMillis();		
		System.out.println("Time for fibRecur to evaluate the 40th Fibonacci number is "+ (tF-tI)+ " ms");
	}
}