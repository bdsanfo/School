/** 
	SinFunc.java finds the sin value
	@author Bobby Sanford
*/


public class SinFunc extends Function{
	/** 
		@param x The double to get the sin value of
		@return value of sin(x)
	*/
	
	public double evaluate(double x){
		return Math.sin(x);
	}
	
}