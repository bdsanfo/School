/**
	PolyBuilder.java decides what to return in order to create a string
	of a polynomial function
	@author Bobby Sanford
*/

import java.util.*;

public class PolyBuilder {

	private String coefficientX = "";
	private String exponent;	
	private String stringI = "";
	private String sign;

	/** 
		Checks to see what coefficient and x should be returned
		@param i the int that is checked
		@return the coefficient and x
	*/
	public String coefficientChoice(int i){ //includes the x variable 
		stringI = Integer.toString(i);
		
		if (i != 0){
			if(i == 1){
				coefficientX = ("x");
			}
			else if(i > 0){
				coefficientX = (stringI + "x");
			}
			else if (i<0) {
				coefficientX = (Integer.toString(Math.abs(i))+ "x");
			}
			else{	//negatives
				coefficientX = (stringI + "x");
			}
		}
		else {
			coefficientX = "";
		}
		
		return coefficientX;
	}
	
	/** 
		Checks to see what exponent should be returned
		@param i the int that is checked
		@return the exponent
	*/
	public String exponentChoice(int i){ //includes ^
		stringI = Integer.toString(i);
		
		if (i != 0 && i != 1){
			exponent = "^" + stringI;
		}
		else {
			exponent = "";
		}
		return exponent;
	}

	/** 
		Checks to see what sign (+ or -) should be returned
		@param i the int that is checked
		@return sign of the int passed in
	*/
	public String signChoice(int i){
		if (i != 0){
			if (i>0){
				sign = "+";
			}
			else {
				sign = "-";
			}
		}
		else {
			sign = "";
		}
		return sign;
	}
}
