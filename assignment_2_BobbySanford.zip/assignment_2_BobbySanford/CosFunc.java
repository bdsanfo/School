/** 
	CosFunc.java finds the cos value
	@author Bobby Sanford
*/

public class CosFunc extends Function{
	/** 
		@param x The double to get the cos value of
		@return value of cos(x)
	*/
	
	public double evaluate(double x){
		return Math.cos(x);
	}
}