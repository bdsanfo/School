/**
	Function.java instantiates the abstract class function and runs tests on the PolyBuilder, PolyFunc,
	SinFunc, and CosFunc classes. It also is able to find the root.
	@author Bobby Sanford
*/

public abstract class Function{
	
	private static final double EPSILON = 0.00000001;

	/**
		abstract method used to evaluate using the extended classes
	*/

	public abstract double evaluate(double x);

	/** 
		Finds the root to the degree of accuracy specified
		@param a double that is compared to b
		@param b double that is compared to a
		@param epsilon degree of accuracy
		@return the root of the doubles passed in
	*/
	public double findRoot(double a, double b, double epsilon){
		double x = (a+b)/2;

		if (Math.abs(a-x) < epsilon){
			return x;
		}
		else if(evaluate(x) < 0 && evaluate(a) < 0){	
			return findRoot(x,b,epsilon);
		}
		else if(evaluate(x) > 0 && evaluate(a) > 0){
			return findRoot(x,b,epsilon);
		}
		else{
			return findRoot(a,x,epsilon);
		}
	}
	
	public static void main(String[] args){
		SinFunc sinFunctionTest = new SinFunc();
		if(sinFunctionTest.findRoot(3,4,EPSILON) != 3.1415926590561867){
			System.out.println("sinTest failed");
		} else { System.out.println("sinTest Passed");}

		CosFunc cosFunctionTest = new CosFunc();
		System.out.println("The root of cos(x) between 1 and 3 is "+cosFunctionTest.findRoot(1,3,EPSILON));

		int[] rootTestArray1 = new int[] {-3,0,1};
		int[] rootTestArray2 = new int[] {-2,1,1};
		PolyFunc rootTestFunction1 = new PolyFunc(rootTestArray1);
		PolyFunc rootTestFunction2 = new PolyFunc(rootTestArray2);

		System.out.println("The positive root of "+rootTestFunction1.toString()+ " is: "+rootTestFunction1.findRoot(0,10,EPSILON));
		System.out.println("The positive root of "+rootTestFunction2.toString()+" is: "+rootTestFunction2.findRoot(0,10,EPSILON));

	}
}