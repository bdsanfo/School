import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.*;

public class GameLost extends JPanel{
	public GameLost(){
		PopupFactory popup = new PopupFactory();

	}
}